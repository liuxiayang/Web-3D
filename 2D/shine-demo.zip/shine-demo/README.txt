A Pen created at CodePen.io. You can find this one at http://codepen.io/NobodyRocks/pen/qzfoc.

 Designed for use with Chrome. hover them :)