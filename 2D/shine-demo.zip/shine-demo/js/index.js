//if some fonts are not being loaded, reload the page
//all fonts hosted on google fonts: https://www.google.com/fonts
//####################################################
//Also check out this!: http://youtu.be/j-e7aBV4nbs
//###################################################